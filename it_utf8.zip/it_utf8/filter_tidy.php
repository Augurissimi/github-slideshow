<?PHP // $Id: filter_tidy.php,v 1.1 2009/04/02 12:53:19 andreabix Exp $ 
      // filter_tidy.php - created with Moodle 2.0 dev (Build: 20090402) (2009040100)


$string['filtername'] = 'HTML tidy';

?>
