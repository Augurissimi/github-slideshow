<?PHP // $Id: gradereport_user.php,v 1.5 2008/11/27 18:54:40 andreabix Exp $ 
      // gradereport_user.php - created with Moodle 2.0 dev (Build: 20081127) (2008112600)


$string['modulename'] = 'Scheda individuale';
$string['user:view'] = 'Visualizzare la propria scheda individuale';

?>
