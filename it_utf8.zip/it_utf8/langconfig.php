<?php
$string['alphabet'] = 'A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z';
$string['backupnameformat'] = '%%Y%%m%%d-%%H%%M';
$string['decsep'] = ',';
$string['firstdayofweek'] = '0';
$string['listsep'] = ';';
$string['locale'] = 'it_IT.UTF-8';
$string['localewin'] = 'Italian_Italy.1252';
$string['localewincharset'] = 'WINDOWS-1252';
$string['oldcharset'] = 'ISO-8859-1';
$string['strftimedate'] = '%%d %%B %%Y';
$string['strftimedateshort'] = '%%d %%B';
$string['strftimedatetime'] = '%%d %%B %%Y, %%H:%%M';
$string['strftimedaydate'] = '%%A, %%d %%B %%Y';
$string['strftimedaydatetime'] = '%%A, %%d %%B %%Y, %%H:%%M';
$string['strftimedayshort'] = '%%A %%d %%B';
$string['strftimedaytime'] = '%%a, %%H:%%M';
$string['strftimemonthyear'] = '%%B %%Y';
$string['strftimerecent'] = '%%d %%b, %%H:%%M';
$string['strftimerecentfull'] = '%%a, %%d %%b %%Y, %%H:%%M';
$string['strftimetime'] = '%%H:%%M';
$string['thischarset'] = 'UTF-8';
$string['thisdirection'] = 'ltr';
$string['thislanguage'] = 'Italiano';
$string['thislanguageint'] = 'Italian';
$string['thousandssep'] = '.';
?>
