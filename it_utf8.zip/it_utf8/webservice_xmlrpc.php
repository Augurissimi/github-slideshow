<?PHP // $Id: webservice_xmlrpc.php,v 1.2 2009/10/28 11:51:53 andreabix Exp $ 
      // webservice_xmlrpc.php - created with Moodle 2.0 dev (Build: 20091028) (2009102700)


$string['pluginname'] = 'Protocollo XML-RPC';
$string['xmlrpc:use'] = 'Usa protocollo XML-RPC';

?>
