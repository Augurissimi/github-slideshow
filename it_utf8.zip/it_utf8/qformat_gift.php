<?PHP // $Id: qformat_gift.php,v 1.1 2009/03/05 11:37:25 andreabix Exp $ 
      // qformat_gift.php - created with Moodle 2.0 dev (Build: 20090304) (2009030300)


$string['nohandler'] = 'Non ci sono gestori per il tipo di domanda $a';

?>
