<?PHP // $Id: coursereport_stats.php,v 1.1 2009/01/30 16:13:56 andreabix Exp $ 
      // coursereport_stats.php - created with Moodle 2.0 dev (Build: 20090128) (2009011900)


$string['stats:view'] = 'Visualizzare le statistiche del corso';

?>
