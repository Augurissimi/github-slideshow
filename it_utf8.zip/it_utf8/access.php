<?PHP // $Id: access.php,v 1.9 2009/06/24 08:00:20 andreabix Exp $ 
      // access.php - created with Moodle 2.0 dev (Build: 20090624) (2009061706)


$string['access'] = 'Accessibilità';
$string['accesshelp'] = 'Aiuto accessibilità';
$string['accesskey'] = 'Tasto, $a';
$string['accessstatement'] = 'Definizione di accessibilità';
$string['activitynext'] = 'Attività successiva';
$string['activityprev'] = 'Attività precedente';
$string['breadcrumb'] = 'Briciole';
$string['cannotdeleterolenoadmin'] = 'Non potete eliminare questo ruolo poiché non ci sono altri utenti con il ruolo di amministratore';
$string['currenttopic'] = 'Questo argomento';
$string['currentweek'] = 'Questa settimana';
$string['hideblocka'] = 'Nascondi blocco $a';
$string['monthnext'] = 'Mese successivo';
$string['monthprev'] = 'Mese precedente';
$string['showblocka'] = 'Mostra blocco $a';
$string['sitemap'] = 'Mappa sito';
$string['skipa'] = 'Salta $a';
$string['skipblock'] = 'Salta blocco';
$string['skipnavigation'] = 'Salta navigazione';
$string['skipto'] = 'Salta a $a';
$string['tabledata'] = 'Tabella dati, $a';
$string['tablelayout'] = 'Tabella layout, $a';
$string['tocontent'] = 'Vai al contenuto principale';
$string['tonavigation'] = 'Vai alla navigazione';
$string['youarehere'] = 'Voi siete qui';

?>
