<?PHP // $Id: block_mnet_hosts.php,v 1.1 2008/02/17 20:33:35 andreabix Exp $ 
      // block_mnet_hosts.php - created with Moodle 1.9 Beta 4 (2007101508)


$string['mnet_hosts'] = 'Network Server';
$string['server'] = 'Server';

?>
