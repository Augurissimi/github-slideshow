<?PHP // $Id$ 
      // journal.php - created with Moodle 1.5 ALPHA (2005050600)


$string['alwaysopen'] = 'Sempre aperto';
$string['blankentry'] = 'Lasciato vuoto';
$string['daysavailable'] = 'Giorni disponibili';
$string['editingended'] = 'Il tempo a disposizione per le modifiche &egrave; terminato';
$string['editingends'] = 'Il tempo a sisposizione per le modifiche termina';
$string['entries'] = 'Annotazioni';
$string['feedbackupdated'] = 'Valutazione aggiornata per $a annotazioni';
$string['journalmail'] = '$a->teacher ha valutato la tua annotazione per \'$a->journal\'.
Puoi vedere la valutazione allegata alla tua annotazione:
$a->url ';
$string['journalmailhtml'] = '$a->teacher ha valutato la tua annotazione per  \'<i>$a->journal\'</i>.<br /><br />
Puoi vedere la valutazione allegata  alla tua <a href=\"$a->url\">annotazione</a>';
$string['journalname'] = 'Nome del diario';
$string['journalquestion'] = 'Domanda del diario';
$string['journalrating1'] = 'Non soddisfacente';
$string['journalrating2'] = 'Soddisfacente';
$string['journalrating3'] = 'Eccezionale';
$string['mailsubject'] = 'Resoconto diario';
$string['modulename'] = 'Diario';
$string['modulenameplural'] = 'Diari';
$string['newjournalentries'] = 'Nuove annotazioni sul diario';
$string['noentry'] = 'Nessuna annotazione';
$string['noratinggiven'] = 'Nessuna valutazione data';
$string['notopenuntil'] = 'Questo diario non sar&agrave;  aperto fino a';
$string['notstarted'] = 'Non hai ancora iniziato questo diario';
$string['overallrating'] = 'Valutazione generale';
$string['rate'] = 'Valutazione';
$string['saveallfeedback'] = 'Salva le mie risposte';
$string['startoredit'] = 'Inizia o modifica la mia annotazione sul diario';
$string['viewallentries'] = 'Vedi $a annotazioni sul diario';

?>
