<?PHP // $Id: block_settings_navigation_tree.php,v 1.1 2009/08/31 14:19:30 andreabix Exp $ 
      // block_settings_navigation_tree.php - created with Moodle 2.0 dev (Build: 20090831) (2009082800)


$string['blockname'] = 'Impostazioni';
$string['enablehoverexpansion'] = 'Abilita l\'espansione del blocco al passaggio del mouse';
$string['enablesidebarpopout'] = 'Gli utenti possono trasformare il blocco in pannello laterale';
$string['toggleblockdisplay'] = 'Riporta a blocco';
$string['togglesidetabdisplay'] = 'Trasforma in pannello laterale';

?>
