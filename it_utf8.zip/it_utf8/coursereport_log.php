<?PHP // $Id: coursereport_log.php,v 1.3 2010/03/29 18:59:44 andreabix Exp $ 
      // coursereport_log.php - created with Moodle 2.0 dev (Build: 20100329) (2010032405)


$string['log:view'] = 'Visualizzare i log del corso';
$string['log:viewlive'] = 'Visualizzare i Live log del corso';
$string['log:viewtoday'] = 'Visualizzare i log di oggi';
$string['loglive'] = 'Live log';

?>
