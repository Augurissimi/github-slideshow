<?PHP // $Id$ 
      // algebra.php - created with Moodle 1.2 Beta + (2004030702)


$string['filtername'] = 'Notazione algebrica';

?>
