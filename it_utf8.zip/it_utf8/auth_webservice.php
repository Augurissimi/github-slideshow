<?PHP // $Id: auth_webservice.php,v 1.2 2009/10/20 08:52:48 andreabix Exp $ 
      // auth_webservice.php - created with Moodle 2.0 dev (Build: 20091014) (2009100605)


$string['auth_webservicedescription'] = 'Account Web service creati manualmente.';
$string['auth_webservicetitle'] = 'Web service';

?>
