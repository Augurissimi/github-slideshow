<?PHP // $Id$ 
      // block_section_links.php - created with Moodle 2.0 dev (Build: 20100217) (2010021400)


$string['blockname'] = 'Collegamenti sezione';
$string['incby1'] = 'Intervallo di';
$string['incby2'] = 'Intervallo alternativo di';
$string['incbydesc1'] = 'L\'intervallo di visualizzazione dei link alle sezioni, con inizio alla sezione 1.';
$string['incbydesc2'] = 'L\'intervallo di visualizzazione alternativo dei link alle sezioni, con inizio alla sezione 1.';
$string['jumptocurrenttopic'] = 'Salta all\'argomento corrente';
$string['jumptocurrentweek'] = 'Salta alla settimana corrente';
$string['numsections1'] = 'Numero di sezioni';
$string['numsections2'] = 'Numero di sezioni alternativo';
$string['numsectionsdesc1'] = 'Se il numero di sezioni del corso raggiunge il valore impostato, verrà utilizzato l\'intervallo definito sotto.';
$string['numsectionsdesc2'] = 'Se il numero di sezioni del corso raggiunge il valore impostato, verrà utilizzato l\'intervallo alternativo definito sotto.';
$string['topics'] = 'Argomenti';
$string['weeks'] = 'Settimane';

?>
