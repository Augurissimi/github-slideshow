<?PHP // $Id$ 
      // choice.php - created with Moodle 2.0 dev (Build: 20090915) (2009091310)


$string['addmorechoices'] = 'Aggiungi più scelte';
$string['allowupdate'] = 'Permetti che le scelte vengano aggiornate';
$string['answered'] = 'Risposta';
$string['choice'] = 'Proposta $a';
$string['choice:choose'] = 'Salvare una scelta';
$string['choice:deleteresponses'] = 'Rimuovere le risposte';
$string['choice:downloadresponses'] = 'Scaricare le risposte';
$string['choice:readresponses'] = 'Leggere le risposte';
$string['choiceadministration'] = 'Gestione Scelta';
$string['choiceclose'] = 'Chiusura';
$string['choicefull'] = 'Questa opzione è completet .';
$string['choicename'] = 'Nome della scelta';
$string['choiceopen'] = 'Apertura';
$string['choicesaved'] = 'la tua scelta è stata salvata';
$string['choicetext'] = 'Testo della domanda';
$string['displayhorizontal'] = 'Mostra orizzontalmente';
$string['displaymode'] = 'Modalità  di visualizzazione';
$string['displayvertical'] = 'Mostra verticalmente';
$string['expired'] = 'Spiacente, questa attività è stata chiusa il $a e non è più disponibile';
$string['fillinatleastoneoption'] = 'Devi fornire almeno due possibili risposte.';
$string['full'] = '(Completo)';
$string['havetologin'] = 'Bisogna effettuare il Login prima di sottomettere la vostra scelta';
$string['limit'] = 'Limite';
$string['limitanswers'] = 'Limitazione scelte';
$string['modulename'] = 'Scelta';
$string['modulenameplural'] = 'Scelte';
$string['mustchooseone'] = 'Bisogna scegliere una risposta prima di salvare. Non è stato salvato nulla.';
$string['noguestchoose'] = 'Spiacenti, gli ospiti non possono effettuare le Scelte.';
$string['noresultsviewable'] = 'I risultati non sono attualmente visualizzabili.';
$string['notanswered'] = 'Ancora nessuna risposta';
$string['notopenyet'] = 'Spiacente, questa attività  non è disponibile fino al $a';
$string['option'] = 'Opzione';
$string['privacy'] = 'Privacy dei risultati';
$string['publish'] = 'Rendi pubblici i risultati';
$string['publishafteranswer'] = 'Mostra i risultati agli studenti dopo che hanno risposto';
$string['publishafterclose'] = 'Mostra i risultati agli studenti solo dopo che la scelta è stata chiusa';
$string['publishalways'] = 'Mostra sempre i risultati agli studenti';
$string['publishanonymous'] = 'Rendi pubblici i risultati in forma anonima. Non mostrare i nomi degli studenti.';
$string['publishnames'] = 'Rendi pubblici i risultati in maniera completa con i nomi e le risposte relative.';
$string['publishnot'] = 'Non rendere pubblici i risultati agli studenti.';
$string['removemychoice'] = 'Cancella la mia scelta';
$string['removeresponses'] = 'Cancella tutte le risposte';
$string['responses'] = 'Risposte';
$string['responsesto'] = 'Risposte a $a';
$string['savemychoice'] = 'Salva la mia risposta';
$string['showunanswered'] = 'Mostra colonna di chi non ha risposto';
$string['spaceleft'] = 'spazio disponibile';
$string['spacesleft'] = 'spazi disponibili';
$string['taken'] = 'Preso';
$string['timerestrict'] = 'Permetti la risposta in questo periodo di tempo';
$string['viewallresponses'] = 'Vedi $a risposte';
$string['yourselection'] = 'La vostra selezione';
$string['cannotsavechoice'] = 'Non è stato possibile salvare la tua scelta'; // ORPHANED
$string['cannotupdatechoice'] = 'Non è stato possibile salvare la tua scelta a causa di un errore nel database'; // ORPHANED

?>
