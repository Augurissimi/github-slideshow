<?PHP // $Id$ 
      // activitynames.php - created with Moodle 2.0 dev (Build: 20090419) (2009041700)


$string['filtername'] = 'Auto link ai Nomi delle attività ';

?>
