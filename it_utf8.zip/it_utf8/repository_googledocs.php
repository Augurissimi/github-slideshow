<?PHP // $Id: repository_googledocs.php,v 1.2 2009/08/31 14:19:29 andreabix Exp $ 
      // repository_googledocs.php - created with Moodle 2.0 dev (Build: 20090831) (2009082800)


$string['googledocs:view'] = 'Visualizzare repository Google Docs';
$string['repositoryname'] = 'Google Docs';

?>
