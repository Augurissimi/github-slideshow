<?PHP // $Id: repository_flickr_public.php,v 1.6 2009/08/31 14:19:29 andreabix Exp $ 
      // repository_flickr_public.php - created with Moodle 2.0 dev (Build: 20090831) (2009082800)


$string['all'] = 'Tutto';
$string['apikey'] = 'API Key';
$string['by'] = 'Licenza d\'uso';
$string['by-nc'] = 'Attribuzione-Licenza NonCommerciale';
$string['by-nc-nd'] = 'Attribuzione-Licenza NonCommerciale-NoOpereDerivate';
$string['by-nc-sa'] = 'Attribuzione-Licenza NonCommerciale-ShareAlike';
$string['by-nd'] = 'Attribuzione-Licenza NoOpereDerivate';
$string['by-sa'] = 'Attribuzione-Licenza ShareAlike';
$string['callbackurl'] = 'Callback URL';
$string['commercialuse'] = 'E\' consentito l\'uso commerciale';
$string['configplugin'] = 'Configurazione Flickr Public';
$string['creativecommonscommercial'] = 'Solamente Creative Commons commerciale';
$string['emailaddress'] = 'Indirizzo email';
$string['flickr_public:view'] = 'Visualizzare repository Flickr Public';
$string['fulltext'] = 'Testo completo';
$string['information'] = '<div>Ottieni una <a href=\"http://www.flickr.com/services/api/keys/\">Flickr API Key</a> per il tuo sito Moodle. </div>';
$string['invalidemail'] = 'Indirizzo email non valido per Flickr';
$string['license'] = 'Licenza';
$string['modification'] = 'E\' consentita la modifica';
$string['notitle'] = 'senza titolo';
$string['nullphotolist'] = 'Questo account non contiene immagini';
$string['remember'] = 'Ricordami';
$string['repositorydesc'] = 'Repository su flickr.com';
$string['repositoryname'] = 'Flickr Public';
$string['secret'] = 'Secret';
$string['sharealike'] = 'Si, con licenza ShareAlike';
$string['tag'] = 'Tag';
$string['username'] = 'Email dell\'account Flickr';
$string['watermark'] = 'Desiderate aggiungere un watermark alle imamgini (ID dell\'autore e URL di provenineza)?';

?>
