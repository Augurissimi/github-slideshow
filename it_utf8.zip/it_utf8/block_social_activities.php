<?PHP // $Id$ 
      // block_social_activities.php - created with Moodle 1.3 development (2004041800)
	  // traduzione a cura di Luca Arese - Universit&agrave;  di Torino


$string['blockname'] = 'Attivit&agrave;  corso';

?>
