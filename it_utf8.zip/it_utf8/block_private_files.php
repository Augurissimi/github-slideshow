<?PHP // $Id: block_private_files.php,v 1.1 2010/03/29 18:59:45 andreabix Exp $ 
      // block_private_files.php - created with Moodle 2.0 dev (Build: 20100329) (2010032405)


$string['blockname'] = 'File personali dell\'utente';
$string['privatefiles'] = 'File personali';

?>
