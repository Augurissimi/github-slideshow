<?PHP // $Id: block_tag_youtube.php,v 1.2 2010/02/19 18:42:16 andreabix Exp $ 
      // block_tag_youtube.php - created with Moodle 2.0 dev (Build: 20100212) (2010020701)


$string['anycategory'] = 'Tutte le categorie';
$string['autosvehicles'] = 'Auto &amp; Veicoli';
$string['blockname'] = 'YouTube';
$string['category'] = 'Categoria';
$string['comedy'] = 'Commedia';
$string['configtitle'] = 'Titolo';
$string['education'] = 'Educazione';
$string['entertainment'] = 'Divertimento';
$string['filmsanimation'] = 'Film &amp; Animazione';
$string['gadgetsgames'] = 'Gadget &amp; Giochi';
$string['howtodiy'] = 'How-to &amp; DIY';
$string['includeonlyvideosfromplaylist'] = 'Includi solo video dalla playlist con id';
$string['music'] = 'Musica';
$string['newspolitics'] = 'Notizie &amp; Politica';
$string['numberofvideos'] = 'Numero di video';
$string['peopleblogs'] = 'Persone &amp; Blog';
$string['petsanimals'] = 'Cuccioli &amp; Animali';
$string['scienceandtech'] = 'Scienza &amp; Tecnologia';
$string['sports'] = 'Sport';
$string['travel'] = 'Viaggi &amp; Luoghi';

?>
