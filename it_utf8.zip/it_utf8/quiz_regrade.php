<?PHP // $Id: quiz_regrade.php,v 1.1 2006/10/23 12:38:34 andreabix Exp $ 
      // quiz_regrade.php - created with Moodle 1.7 beta (2006101000)


$string['regrade'] = 'Rivalutazione';

?>
