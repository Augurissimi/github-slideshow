<?PHP // $Id: gradereport_grader.php,v 1.6 2010/02/19 18:42:17 andreabix Exp $ 
      // gradereport_grader.php - created with Moodle 2.0 dev (Build: 20100217) (2010021400)


$string['ajaxchoosescale'] = 'Scegli';
$string['ajaxclicktoclose'] = 'Fai click sul box per rimuoverlo';
$string['ajaxerror'] = 'Errore';
$string['ajaxfailedupdate'] = 'Impossibile aggiornare [1] per [2]';
$string['ajaxfieldchanged'] = 'Il campo che stai modificando è cambiato, desideri usare il valore aggiornato)';
$string['grader:manage'] = 'Gestire il registro valutatore';
$string['grader:view'] = 'Visualizzare il registro valutatore';
$string['modulename'] = 'Registro valutatore';
$string['preferences'] = 'Preferenze registro valutatore';

?>
