<?PHP // $Id: repository_picasa.php,v 1.2 2009/08/31 14:19:29 andreabix Exp $ 
      // repository_picasa.php - created with Moodle 2.0 dev (Build: 20090831) (2009082800)


$string['picasa:view'] = 'Visualizzare repository Picasa';
$string['repositoryname'] = 'Web Album Picasa';

?>
