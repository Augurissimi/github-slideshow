<?PHP // $Id: repository_wikimedia.php,v 1.2 2009/08/31 14:19:29 andreabix Exp $ 
      // repository_wikimedia.php - created with Moodle 2.0 dev (Build: 20090831) (2009082800)


$string['keyword'] = 'Nome immagine';
$string['repositoryname'] = 'Wikimedia';
$string['wikimedia:view'] = 'Visualizzare repository Wikimedia';

?>
