<?PHP // $Id$ 
      // block_course_summary.php - created with Moodle 1.5 ALPHA (2005043000)


$string['coursesummary'] = 'Sommario del corso';
$string['pagedescription'] = 'Descrizione del corso/sito';

?>
