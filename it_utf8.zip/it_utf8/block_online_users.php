<?PHP // $Id$ 
      // block_online_users.php - created with Moodle 2.0 dev (Build: 20090128) (2009011900)


$string['blockname'] = 'Utenti online';
$string['configtimetosee'] = 'Numero di minuti di inattività trascorsi i quali un utente non è più considerato online.';
$string['online_users:viewlist'] = 'Visualizzare elenco degli utenti online';
$string['periodnminutes'] = 'ultimi $a minuti';
$string['timetosee'] = 'Rimuovi dopo inattività (minuti)';

?>
