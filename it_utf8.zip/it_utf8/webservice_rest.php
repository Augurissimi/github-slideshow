<?PHP // $Id: webservice_rest.php,v 1.2 2009/10/28 11:51:53 andreabix Exp $ 
      // webservice_rest.php - created with Moodle 2.0 dev (Build: 20091028) (2009102700)


$string['pluginname'] = 'Protocollo REST';
$string['rest:use'] = 'Usa protocollo REST';

?>
