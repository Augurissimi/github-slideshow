<?PHP // $Id: coursereport_progress.php,v 1.1 2009/01/30 16:13:56 andreabix Exp $ 
      // coursereport_progress.php - created with Moodle 2.0 dev (Build: 20090128) (2009011900)


$string['progress:view'] = 'Visualizzare stato di avanzamento';

?>
