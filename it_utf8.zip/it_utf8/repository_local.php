<?PHP // $Id: repository_local.php,v 1.4 2009/08/31 14:19:29 andreabix Exp $ 
      // repository_local.php - created with Moodle 2.0 dev (Build: 20090831) (2009082800)


$string['configplugin'] = 'Configurazione per il repository File Locali';
$string['currentusefiles'] = 'File in uso';
$string['emptyfilelist'] = 'Non ci sono file da visualizzare';
$string['local:view'] = 'Visualizzare repository File Locali';
$string['notitle'] = 'senza titolo';
$string['remember'] = 'Ricordami';
$string['repositorydesc'] = 'Repository nel Sever Moodle locale';
$string['repositoryname'] = 'File Locali';

?>
