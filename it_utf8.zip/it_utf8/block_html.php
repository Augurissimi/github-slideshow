<?PHP // $Id$ 
      // block_html.php - created with Moodle 1.5 ALPHA (2005043000)
	  // traduzione a cura di Luca Arese - Universit&agrave;  di Torino


$string['configcontent'] = 'Contenuto';
$string['configtitle'] = 'Titolo blocco';
$string['html'] = 'HTML';
$string['leaveblanktohide'] = 'lasciare in bianco per nascondere il titolo';
$string['newhtmlblock'] = '(nuovo blocco HTML)';

?>
