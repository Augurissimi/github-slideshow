<?PHP // $Id: mimetypes.php,v 1.2 2006/10/18 10:01:04 bobopinna Exp $ 
      // mimetypes.php - created with Moodle 1.8 dev (2006101001)


$string['application/msword'] = 'documento Word';
$string['application/pdf'] = 'documento PDF';
$string['application/vnd.ms-excel'] = 'foglio di calcolo Excel';
$string['application/vnd.ms-powerpoint'] = 'presentazione Powerpoint';
$string['application/zip'] = 'achivio zip';
$string['audio/mp3'] = 'file audio MP3';
$string['audio/wav'] = 'file audio';
$string['document/unknown'] = 'file';
$string['image/bmp'] = 'immagine BMP';
$string['image/gif'] = 'immagine GIF';
$string['image/jpeg'] = 'immagine JPEG';
$string['text/plain'] = 'file di testo';
$string['text/rtf'] = 'documento RTF';

?>
