<?PHP // $Id: qtype_truefalse.php,v 1.3 2009/03/02 17:00:08 andreabix Exp $ 
      // qtype_truefalse.php - created with Moodle 2.0 dev (Build: 20090302) (2009021800)


$string['addingtruefalse'] = 'Creazione domanda Vero/Falso';
$string['correctanswer'] = 'Risposta corretta';
$string['editingtruefalse'] = 'Modifica domanda Vero/Falso';
$string['false'] = 'Falso';
$string['feedbackfalse'] = 'Feedback (Falso)';
$string['feedbacktrue'] = 'Feedback (Vero)';
$string['true'] = 'Vero';
$string['truefalse'] = 'Vero/Falso';
$string['truefalsesummary'] = 'Una declinazione delle domande a risposta multipla con solo due alternative, \'Vero\' e \'Falso\'.';

?>
