<?PHP // $Id: gradeexport_txt.php,v 1.5 2009/01/26 12:40:34 andreabix Exp $ 
      // gradeexport_txt.php - created with Moodle 2.0 dev (Build: 20090123) (2009011900)


$string['modulename'] = 'Formato testo';
$string['txt:publish'] = 'Pubblicare le valutazioni in formato testo';
$string['txt:view'] = 'Esportare le valutazioni in formato testo';

?>
