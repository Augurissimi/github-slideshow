<?PHP // $Id: block_blog_recent.php,v 1.2 2009/11/06 14:41:57 andreabix Exp $ 
      // block_blog_recent.php - created with Moodle 2.0 dev (Build: 20091102) (2009103000)


$string['blockname'] = 'Interventi Blog recenti';
$string['norecentblogentries'] = 'Non ci sono interventi recenti';
$string['numentriestodisplay'] = 'Numero di interventi recenti da visualizzare';
$string['recentinterval'] = 'Intervallo di tempo entro il quale considerare \"recente\" un intervento';

?>
