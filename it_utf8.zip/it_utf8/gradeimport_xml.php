<?PHP // $Id: gradeimport_xml.php,v 1.5 2008/11/27 18:54:39 andreabix Exp $ 
      // gradeimport_xml.php - created with Moodle 2.0 dev (Build: 20081127) (2008112600)


$string['errbadxmlformat'] = 'Errore - formato XML non corretto';
$string['errduplicategradeidnumber'] = 'Errore - ci sono due elementi di valutazione in questo corso con idnumber \'$a\'. Questo non dovrebbe essere possibile.';
$string['errduplicateidnumber'] = 'Errore - idnumber duplicato';
$string['errincorrectgradeidnumber'] = 'Errore - l\'idnumber \'$a\' dal file di importazione non corrisponde ad alcun elemento di valutazione.';
$string['errincorrectidnumber'] = 'Errore - idnumber errato';
$string['errincorrectuseridnumber'] = 'Errore - l\'idnumber \'$a\' dal file di importazione non corrisponde a nessun utente.';
$string['error'] = 'Si stanno verificando errori';
$string['fileurl'] = 'URL del file remoto';
$string['modulename'] = 'File XML';
$string['xml:publish'] = 'Pubblicare le valutazioni importate da XML';
$string['xml:view'] = 'Importare le valutazioni da XML';

?>
