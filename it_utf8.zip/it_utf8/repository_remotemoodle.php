<?PHP // $Id: repository_remotemoodle.php,v 1.5 2009/08/31 14:19:29 andreabix Exp $ 
      // repository_remotemoodle.php - created with Moodle 2.0 dev (Build: 20090831) (2009082800)


$string['configplugin'] = 'Configurazione repository Moodle Remoto';
$string['connectionfailure'] = 'Non è stato possibile ottenere l\'elenco dei file. E\' possibile che il Moodle remoto non sia alla versione 2.0 oppure che il Servizio di Repository Moodle Remoto non sia stato attivato';
$string['emptyfilelist'] = 'Non ci sono file da visualizzare';
$string['failtoretrievelist'] = 'Non è stato possibile ottenere l\'elenco oppure l\'elenco è vuoto';
$string['hostnotfound'] = 'Non è stato possibile trovare il Moodle remoto nel database. Contattate il vostro amministratore';
$string['nopeer'] = '<div>Per favore attivate alcuni <a href=\"http://docs.moodle.org/en/admin/mnet/peers#Peer_to_Peer_Network\">Moodle peer</a> per il vostro sito Moodle. </div>';
$string['notitle'] = 'senza titolo';
$string['peer'] = 'Peer';
$string['remember'] = 'Ricordami';
$string['remotemoodle:view'] = 'Visualizzare repository Moodle remoto';
$string['remoterep_description'] = 'Abilita il \"discovery\" del servizio<br><br>';
$string['remoterep_name'] = 'Repository Moodle Remoto';
$string['repositorydesc'] = 'Repository sul server Moodle remoto';
$string['repositoryname'] = 'Moodle remoto';
$string['usercannotaccess'] = 'Tu ($a) non puoi accedere a questo file';
$string['usernotfound'] = 'L\'utente $a non ha un account nel server Moodle remoto';

?>
