<?PHP // $Id: qformat_xml.php,v 1.1 2009/03/23 19:36:54 andreabix Exp $ 
      // qformat_xml.php - created with Moodle 2.0 dev (Build: 20090318) (2009030501)


$string['invalidxml'] = 'File XML non valido - atteso string (usa CDATA?)';
$string['unsupportedexport'] = 'Il tipo di domanda $a non è supportato dall\'export XML';

?>
