<?PHP // $Id$ 
      // quiz_analysis.php - created with Moodle 2.0 dev (Build: 20090416) (2009040601)


$string['analysis'] = 'Analisi';
$string['analysisdownload'] = 'Download analisi';
$string['analysisoptions'] = 'Opzioni di analisi';
$string['analysisreport'] = 'Report Analisi degli elementi';
$string['analysistitle'] = 'Tabella per l\'analisi dei risultati';
$string['attemptsall'] = 'tutti i tentativi';
$string['attemptselection'] = 'Tentativi da analizzare per utente';
$string['attemptsfirst'] = 'primo tentativo';
$string['attemptshighest'] = 'voto più alto';
$string['attemptslast'] = 'ultimo tentativo';
$string['dicsindextitle'] = 'Indice<br />discrim.';
$string['disccoefftitle'] = 'Coeff.<br />discrim.';
$string['downloadhtml'] = 'Scarica la tabella in formato HTML';
$string['downloadooo'] = 'Download in formato OpenOffice';
$string['facilitytitle'] = '%% Giuste<br>Facilità';
$string['lowmarkslimit'] = 'Non analizzare se il punteggio è minore di:';
$string['pagesize'] = 'Domande per pagina:';
$string['qcounttitle'] = 'Conteggio dom.';
$string['qidtitle'] = 'D#';
$string['qnametitle'] = 'Nome domanda';
$string['qtexttitle'] = 'Testo domanda';
$string['qtypetitle'] = 'Tipo dom.';
$string['quizreportdir'] = 'risultati_quiz';
$string['rcounttitle'] = 'Num.<br />risposte';
$string['reportanalysis'] = 'Analisi dei risultati';
$string['responsestitle'] = 'Testo risposta';
$string['rfractiontitle'] = 'Credito<br />parziale';
$string['rpercenttitle'] = '%%<br />risposte';
$string['stddevtitle'] = 'Deviaz.<br />standard';

?>
