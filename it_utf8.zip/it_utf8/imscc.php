<?PHP // $Id: imscc.php,v 1.1 2009/10/26 17:54:17 andreabix Exp $ 
      // imscc.php - created with Moodle 2.0 dev (Build: 20091023) (2009102201)


$string['cc2moodle_checking_schema'] = 'Fomrmato CC! E\' in corso il controllo dello Schema...';
$string['cc2moodle_invalid_schema'] = 'Lo Schema non è valido.';
$string['cc2moodle_manifest_dont_load'] = 'Non è possibile caricare il manifest XML.';
$string['cc2moodle_req_auth'] = 'ERRORE: il pacchetto Common Cartridge richiede una autorizzazione.';
$string['cc2moodle_valid_schema'] = 'Lo schema è valido!';
$string['cc_import_req_dom'] = 'ERRORE: l\'importazione Common Cartridge richiede l\'estensione DOM.';
$string['cc_import_req_libxml'] = 'ERRORE: l\'importazione Common Cartridge richiede l\'estensione LIBXML.';
$string['cc_import_req_libxmlminversion'] = 'ERRORE: l\'importazione Common Cartridge richiede l\'estensione LIBXML versione 2.6.30 o successiva.';
$string['cc_import_req_php5'] = 'ERRORE: l\'importazione Common Cartridge richiede il PHP versione 5 o successivo.';
$string['cc_import_req_xsl'] = 'ERRORE: l\'importazione Common Cartridge richiede XSL.';
$string['checkingforimscc'] = 'Controllo per IMS-CC';
$string['enable_cc_import'] = 'Abilita importazione CC';
$string['enable_cc_import_description'] = 'L\'impostazione abilita l\'importazione di pacchetti Common Cartridge (IMS-CC) attraverso la funzione di ripristino standard. Prerequisiti per il funzionamento sono PHP5, DOM, XSL e LIBXML (2.6.30 o successiva).';

?>
