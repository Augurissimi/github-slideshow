<?PHP // $Id: portfolio_googledocs.php,v 1.1 2009/01/30 18:52:54 andreabix Exp $ 
      // portfolio_googledocs.php - created with Moodle 2.0 dev (Build: 20090128) (2009011900)


$string['noauthtoken'] = 'Non è stato possibile ricevere un token di autenticazione da Google. Accertatevi di aver consentito a Moodle di accedere al vostro account Google';
$string['nosessiontoken'] = 'Non esiste un token di sessione e non è possibile esportare file su Google.';
$string['pluginname'] = 'Google Docs';
$string['sendfailed'] = 'Non è stato possibile trasferire il file $a su Google';

?>
