<?PHP // $Id: repository_merlot.php,v 1.1 2009/11/19 17:53:30 andreabix Exp $ 
      // repository_merlot.php - created with Moodle 2.0 dev (Build: 20091117) (2009111702)


$string['configplugin'] = 'Configurazione Merlot.org';
$string['licensekey'] = 'Chiave licenza';
$string['repositorydesc'] = 'Merlot.org';
$string['repositoryname'] = 'Merlot.org';

?>
