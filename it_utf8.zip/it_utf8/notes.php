<?PHP // $Id: notes.php,v 1.3 2009/10/20 08:52:48 andreabix Exp $ 
      // notes.php - created with Moodle 2.0 dev (Build: 20091014) (2009100605)


$string['addnewnote'] = 'Aggiungi una annotazione';
$string['addnewnoteselect'] = 'Seleziona gli utenti sui quali scrivere l\'annotazione';
$string['bynameondate'] = 'di $a->name - $a->date';
$string['cannotdeletepost'] = 'Si è verificato un errore durante l\'eliminazione dell\'annotazione.';
$string['configenablenotes'] = 'Permette di scrivere annotazioni sugli utenti';
$string['content'] = 'Contenuto';
$string['course'] = 'corso';
$string['coursenotes'] = 'Annotazioni corso';
$string['created'] = 'creata';
$string['deleteconfirm'] = 'Confermi l\'eliminazione?';
$string['deletenotes'] = 'Elimina tutte le annotazioni';
$string['editnote'] = 'Modifica annotazione';
$string['enablenotes'] = 'Abilita annotazioni';
$string['groupaddnewnote'] = 'Aggiungi una nuova annotazione per tutti';
$string['invalidid'] = 'E\' stato indicato una ID errata dell\'annotazione';
$string['nocontent'] = 'Il contenuto della annotazione non può essere vuoto';
$string['nonotes'] = 'Non ci sono ancora annotazioni di questo tipo';
$string['nopermissiontodelete'] = 'Potresti non essere autorizzato ad eliminare questa note';
$string['note'] = 'Annotazione';
$string['notes'] = 'Annotazioni';
$string['notesdisabled'] = 'Siamo spiacenti ma le annotazioni sono disabilitate.';
$string['notesnotvisible'] = 'Non sei autorizzato a vedere le annotazioni.';
$string['nouser'] = 'Devi scegliere un utente';
$string['personal'] = 'personale';
$string['personalnotes'] = 'Annotazioni personali';
$string['publishstate'] = 'Stato';
$string['site'] = 'sito';
$string['sitenotes'] = 'Annotazioni del sito';
$string['unknown'] = 'sconosciuto';

?>
