<?PHP // $Id: qtype_calculated.php,v 1.4 2009/03/02 17:00:08 andreabix Exp $ 
      // qtype_calculated.php - created with Moodle 2.0 dev (Build: 20090302) (2009021800)


$string['addingcalculated'] = 'Creazione domanda Calcolata';
$string['addmoreanswerblanks'] = 'Aggiungi un altro spazio risposta.';
$string['addmoreunitblanks'] = 'Spazi per altre $a unità';
$string['answerhdr'] = 'Risposta';
$string['atleastoneanswer'] = 'E\' necessario fornire almeno una risposta.';
$string['calculated'] = 'Calcolata';
$string['calculatedsummary'] = 'Le domande Calcolate sono simili alla domande Numeriche dove però i numeri utilizzati sono scelti a caso durante lo svolgimento del quiz.';
$string['correctanswershows'] = 'Mostra risposta corretta';
$string['correctanswershowsformat'] = 'Formato';
$string['editingcalculated'] = 'Modifica domanda Calcolata';
$string['existingcategory1'] = 'userà un dataset condiviso e preesistente';
$string['keptcategory1'] = 'userà lo stesso dataset condiviso e preesistente di prima';
$string['keptlocal1'] = 'userà lo stesso dataset privato e preesistente di prima';
$string['makecopynextpage'] = 'Prossima pagina (nuova domanda)';
$string['mandatoryhdr'] = 'Carattere jolly obbligatorio nelle risposte';
$string['mustbenumeric'] = 'Deve essere inserito un numero.';
$string['mustnotbenumeric'] = 'Questo non può essere un numero.';
$string['newcategory1'] = 'userà un nuovo dataset condiviso';
$string['newlocal1'] = 'userà un nuovo dataset privato';
$string['nextitemtoadd'] = 'Prossimo \'Item da aggiungere\'';
$string['nextpage'] = 'Prossima pagina';
$string['nodataset'] = 'niente - non è un carattere jolly';
$string['nosharedwildcard'] = 'Nessun carattere jolly condiviso in questa categoria';
$string['possiblehdr'] = 'Possibili caratteri jolly solo nel testo della domanda';
$string['tolerance'] = 'Tolleranza &plusmn;';
$string['trueanswerinsidelimits'] = 'Risposta corretta: $a->correct dentro i limiti del valore vero $a->true';
$string['trueansweroutsidelimits'] = '<span class=\"error\">ERRORE Risposta corretta: $a->correct fuori dai limiti del valore vero $a->true</span>';
$string['updatecategory'] = 'Aggiorna la categoria';
$string['usedinquestion'] = 'Usato nella domanda';
$string['youmustenteramultiplierhere'] = 'Deve essere inserito un moltiplicatore.';

?>
