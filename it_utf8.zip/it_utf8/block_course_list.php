<?PHP // $Id$ 
      // block_course_list.php - created with Moodle 1.9 Beta 3 (2007101506)


$string['adminview'] = 'Vista amministratore';
$string['allcourses'] = 'L\'amministratore vede tutti i corsi disponibili';
$string['blockname'] = 'Elenco Corsi';
$string['configadminview'] = 'Cosa dovrebbe vedere l\'Amministratore nel blocco \"Elenco corsi\"?';
$string['confighideallcourseslink'] = 'Non mostrare agli utenti il link \"Tutti i corsi\" in fondo al blocco.';
$string['hideallcourseslink'] = 'Nascondi link \"Tutti i corsi\"';
$string['owncourses'] = 'L\'amministratore vede solo i corsi nei quali partecipa';

?>
