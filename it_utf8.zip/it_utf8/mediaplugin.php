<?PHP // $Id$ 
      // mediaplugin.php - created with Moodle 1.9.11 (Build: 20110221) (2007101591.02)


$string['filtername'] = 'Plugin multimediali';
$string['flashanimation'] = 'Animazione Flash';
$string['flashvideo'] = 'Video Flash';
$string['mp3audio'] = 'Audio MP3';
$string['oggaudio'] = 'OGG audio
OGG audio
OGG audio';
$string['ogvvideo'] = 'OCV video';
$string['quicktime'] = 'Quicktime';
$string['realaudio'] = 'Real audio';
$string['unsupportedplugins'] = '(Il browser non supporta i file di questo tipo. {$a})';
$string['wmpvideo'] = 'WMP video';

?>
