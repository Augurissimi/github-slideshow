<?PHP // $Id: qtype_calculatedsimple.php,v 1.1 2009/06/03 15:07:17 andreabix Exp $ 
      // qtype_calculatedsimple.php - created with Moodle 2.0 dev (Build: 20090603) (2009051700)


$string['addingcalculatedsimple'] = 'Aggiungi domanda Calcolata Semplice';
$string['atleastonewildcard'] = 'Almeno un Jolly <strong>{x..}</strong> dovrebbe essere presente nelle formule delle risposte corrette.';
$string['calculatedsimple'] = 'Calcolata Semplice';
$string['calculatedsimplesummary'] = 'E\' una versione semplificata della Domanda Calcolata. Sono simili alle domande numeriche ma i numeri sono scelti casualmente da un insieme durante lo svolgimento del quiz.';
$string['converttocalculated'] = 'Salva come nuova domanda Calcolata semplice standard';
$string['editingcalculatedsimple'] = 'Modifica domanda Calcolata Semplice';
$string['findwildcards'] = 'Trova i Jolly  {x..} presenti nelle formule delle risposte correte';
$string['generatenewitemsset'] = 'Genera';
$string['mustbenumeric'] = 'Dovete inserire un numero.';
$string['mustnotbenumeric'] = 'Non può essere un numero.';
$string['newsetwildcardvalues'] = 'nuovo set di valori Jolly';
$string['setno'] = 'Imposta $a';
$string['setwildcardvalues'] = 'set di valori Jolly';
$string['showitems'] = 'Visualizza';
$string['updatewildcardvalues'] = 'Aggiorna i valori Jolly';
$string['useadvance'] = 'Per visualizzare gli errori usate il pulsante Avanti.';
$string['wildcard'] = 'Jolly {<strong>$a</strong>}';
$string['wildcardparam'] = 'Parametri Jolly utilizzati per generare i valori';
$string['wildcardrole'] = 'I Jolly <strong>{x..}</strong> saranno sostituiti da un valore numerico preso dai valori generati';
$string['wildcardvalues'] = 'Valori Jolly';
$string['wildcardvaluesgenerated'] = 'Valori Jolly generati';
$string['willconverttocalculated'] = 'Se impostato, <strong>Salva come nuova domanda</strong> salverà come nuova domanda calcolata';
$string['youmustaddatleastonevalue'] = 'Dovete aggiungere almeno un set di Jolly prima di poter salvare la domanda';

?>
