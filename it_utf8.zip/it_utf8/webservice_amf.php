<?PHP // $Id: webservice_amf.php,v 1.2 2009/10/28 11:51:53 andreabix Exp $ 
      // webservice_amf.php - created with Moodle 2.0 dev (Build: 20091028) (2009102700)


$string['amf:use'] = 'Usa protocollo AMF';
$string['pluginname'] = 'Protocollo AMF';
$string['amfdebug'] = 'Modalità debug server AMF'; // ORPHANED

?>
