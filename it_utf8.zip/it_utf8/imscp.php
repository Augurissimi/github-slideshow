<?PHP // $Id: imscp.php,v 1.2 2010/01/04 19:52:44 andreabix Exp $ 
      // imscp.php - created with Moodle 2.0 dev (Build: 20100104) (2010010300)


$string['areabackup'] = 'Archivio pacchetti';
$string['areacontent'] = 'Contenuto';
$string['contentheader'] = 'Contenuto';
$string['deploymenterror'] = 'Si è verificato un errore nel pacchetto';
$string['imscpadministration'] = 'Gestione IMSCP';
$string['keepold'] = 'Pacchetti da archiviare';
$string['keepoldexplain'] = 'Quanti pacchetti devono essere archiviati?';
$string['modulename'] = 'IMS Content Package';
$string['modulenameplural'] = 'IMS Content Package';
$string['navigation'] = 'Navigazione';
$string['packagefile'] = 'File del pacchetto';
$string['toc'] = 'TOC';

?>
