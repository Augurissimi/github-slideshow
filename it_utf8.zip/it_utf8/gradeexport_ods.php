<?PHP // $Id: gradeexport_ods.php,v 1.5 2009/01/26 12:40:34 andreabix Exp $ 
      // gradeexport_ods.php - created with Moodle 2.0 dev (Build: 20090123) (2009011900)


$string['modulename'] = 'Formato OpenDocument';
$string['ods:publish'] = 'Pubblicare le valutazioni in formato ODS';
$string['ods:view'] = 'Esportare le valutazioni in formato OpenDocument';

?>
