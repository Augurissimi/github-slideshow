<?PHP // $Id: auth_imap.php,v 1.1 2009/06/11 16:35:18 andreabix Exp $ 
      // created with Moodle 2.0 dev (Build: 20090603) (2009060200)

$string['auth_imapchangepasswordurl_key'] = 'URL per cambiare password';
$string['auth_imapdescription'] = 'Questo metodo usa un server IMAP per controllare se il nome utente e la password dati sono validi.';
$string['auth_imaphost'] = 'Indirizzo server IMAP. Usa il numero IP, non il nome DNS.';
$string['auth_imaphost_key'] = 'Host';
$string['auth_imapnotinstalled'] = 'L\'autenticazione IMAP non può essere utilizzata. Il modulo PHP IMAP non è installato.';
$string['auth_imapport'] = 'Porta server IMAP. Normalmente è 143 o 993.';
$string['auth_imapport_key'] = 'Porta';
$string['auth_imaptitle'] = 'Server IMAP';
$string['auth_imaptype'] = 'Tipo di server IMAP. I server IMAP possono avere modi  differenti di autenticazione e negoziazione.';
$string['auth_imaptype_key'] = 'Tipo';

?>
