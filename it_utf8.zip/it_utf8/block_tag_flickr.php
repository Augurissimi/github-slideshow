<?PHP // $Id: block_tag_flickr.php,v 1.1 2008/01/07 16:48:43 andreabix Exp $ 
      // block_tag_flickr.php - created with Moodle 1.9 Beta 3 (2007101506)


$string['blockname'] = 'Flickr';
$string['configtitle'] = 'Titolo';
$string['date-posted-asc'] = 'Data invio ASC';
$string['date-posted-desc'] = 'Data invio DISC';
$string['date-taken-asc'] = 'Data scatto ASC';
$string['date-taken-desc'] = 'Data scatto DISC';
$string['defaulttile'] = 'Flickr';
$string['getfromphotoset'] = 'Prendi foto da photoset con id';
$string['includerelatedtags'] = 'Includi tag correlate nella query';
$string['interestingness-asc'] = 'Interesse ASC';
$string['interestingness-desc'] = 'Interesse DISC';
$string['numberofphotos'] = 'Numero di foto';
$string['relevance'] = 'Rilevanza';
$string['sortby'] = 'Ordinate per';

?>
