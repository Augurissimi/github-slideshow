<?PHP // $Id: qtype_randomsamatch.php,v 1.4 2009/05/20 09:14:32 andreabix Exp $ 
      // qtype_randomsamatch.php - created with Moodle 2.0 dev (Build: 20090302) (2009021800)


$string['addingrandomsamatch'] = 'Creazione Corrispondenze di domande a Risposta Breve';
$string['editingrandomsamatch'] = 'Modifica Corrispondenze di domande a Risposta Breve';
$string['nosaincategory'] = 'Non ci sono domande a risposta breve nella categoria scelta \'<b>$a->catname</b>\'. Scegli un\'altra categoria o inserisce qualche domanda in questa categoria.';
$string['notenoughsaincategory'] = 'Ci sono solo <b>$a->nosaquestions</b> domande a risposta breve nella categoria scelta \'<b>$a->catname</b>\'. Scegli un\'altra categoria, aggiungi alcune domande in questa categoria o riduci il numero di domande che hai definito.';
$string['randomsamatch'] = 'Corrispondenze con domande a Risposta Breve';
$string['randomsamatchsummary'] = 'Simile alla domanda Corrispondenza ma creata pescando a caso domande a Risposta breve presenti in una data categoria.';

?>
