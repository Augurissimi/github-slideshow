<?PHP // $Id$

$string['-about'] = "A proposito di Moodle";
$string['intro.html'] = "Introduzione";
$string['background.html'] = "Contesto";
$string['philosophy.html'] = "Filosofia";
$string['licence.html'] = "Licenza";
$string['features.html'] = "Caratteristiche";
$string['release.html'] = "Note di rilascio";
$string['future.html'] = "Novit&agrave; nelle prossime versioni";
$string['credits.html'] = "Ringraziamenti";

$string['-installation'] = "Amministrazione";
$string['install.html'] = "Installazione";
$string['faq.html'] = "Domande frequenti (FAQ)";
$string['installamp.html'] = "Apache, MySQL, PHP";
$string['upgrade.html'] = "Aggiornamento";

$string['-usage'] = "Utilizzo di Moodle";
$string['teacher.html'] = "Manuale dell'insegnante";
$string['other.html'] = "Documentazione aggiuntiva";

$string['-development'] = "Sviluppo";
$string['developer.html'] = "Manuale dello sviluppatore";
$string['coding.html'] = "Linee guida per lo sviluppo";
$string['cvs.html'] = "Come usare CVS";
$string['translation.html'] = "Traduzione";






?>